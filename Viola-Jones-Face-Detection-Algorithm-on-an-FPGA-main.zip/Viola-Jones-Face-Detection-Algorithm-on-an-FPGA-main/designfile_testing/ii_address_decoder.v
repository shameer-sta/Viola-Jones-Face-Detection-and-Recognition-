// ==========================================================================
// ii_address_decoder.v - selects and addresses the 12 feature corners
// --------------------------------------------------------------------------
// For corner index 0..11 picks the rectangle (0..2) and corner (A..D) and
// computes its integral-image buffer address (ii_address_calc).
// Used by: subwindow_top.v
// ==========================================================================

module ii_address_decoder (
    input  wire [3:0]  ii_reg_index,
    input  wire [5:0]  width_ii,
    input  wire [12:0] p_offset,

    input  wire [4:0]  x_rect0,
    input  wire [4:0]  x_rect1,
    input  wire [4:0]  x_rect2,

    input  wire [4:0]  y_rect0,
    input  wire [4:0]  y_rect1,
    input  wire [4:0]  y_rect2,

    input  wire [4:0]  w_rect0,
    input  wire [4:0]  w_rect1,
    input  wire [4:0]  w_rect2,

    input  wire [4:0]  h_rect0,
    input  wire [4:0]  h_rect1,
    input  wire [4:0]  h_rect2,

    output reg [12:0] ii_address
);

    wire [4:0] x_rect0_plus_w_rect0;
    wire [4:0] x_rect1_plus_w_rect1;
    wire [4:0] x_rect2_plus_w_rect2;

    wire [4:0] y_rect0_plus_h_rect0;
    wire [4:0] y_rect1_plus_h_rect1;
    wire [4:0] y_rect2_plus_h_rect2;

    wire [12:0] ii_address0;
    wire [12:0] ii_address1;
    wire [12:0] ii_address2;
    wire [12:0] ii_address3;
    wire [12:0] ii_address4;
    wire [12:0] ii_address5;
    wire [12:0] ii_address6;
    wire [12:0] ii_address7;
    wire [12:0] ii_address8;
    wire [12:0] ii_address9;
    wire [12:0] ii_address10;
    wire [12:0] ii_address11;

    /*
     * x_rect + w_rect
     */
    assign x_rect0_plus_w_rect0 = x_rect0 + w_rect0;
    assign x_rect1_plus_w_rect1 = x_rect1 + w_rect1;
    assign x_rect2_plus_w_rect2 = x_rect2 + w_rect2;

    /*
     * y_rect + h_rect
     */
    assign y_rect0_plus_h_rect0 = y_rect0 + h_rect0;
    assign y_rect1_plus_h_rect1 = y_rect1 + h_rect1;
    assign y_rect2_plus_h_rect2 = y_rect2 + h_rect2;

    /*
     * Rectangle 0
     */

    ii_address_calc ii_addr0 (
        .x_pos_point(x_rect0),
        .y_pos_point(y_rect0),
        .width_ii(width_ii),
        .p_offset(p_offset),
        .ii_address(ii_address0)
    );

    ii_address_calc ii_addr1 (
        .x_pos_point(x_rect0_plus_w_rect0),
        .y_pos_point(y_rect0),
        .width_ii(width_ii),
        .p_offset(p_offset),
        .ii_address(ii_address1)
    );

    ii_address_calc ii_addr2 (
        .x_pos_point(x_rect0),
        .y_pos_point(y_rect0_plus_h_rect0),
        .width_ii(width_ii),
        .p_offset(p_offset),
        .ii_address(ii_address2)
    );

    ii_address_calc ii_addr3 (
        .x_pos_point(x_rect0_plus_w_rect0),
        .y_pos_point(y_rect0_plus_h_rect0),
        .width_ii(width_ii),
        .p_offset(p_offset),
        .ii_address(ii_address3)
    );

    /*
     * Rectangle 1
     */

    ii_address_calc ii_addr4 (
        .x_pos_point(x_rect1),
        .y_pos_point(y_rect1),
        .width_ii(width_ii),
        .p_offset(p_offset),
        .ii_address(ii_address4)
    );

    ii_address_calc ii_addr5 (
        .x_pos_point(x_rect1_plus_w_rect1),
        .y_pos_point(y_rect1),
        .width_ii(width_ii),
        .p_offset(p_offset),
        .ii_address(ii_address5)
    );

    ii_address_calc ii_addr6 (
        .x_pos_point(x_rect1),
        .y_pos_point(y_rect1_plus_h_rect1),
        .width_ii(width_ii),
        .p_offset(p_offset),
        .ii_address(ii_address6)
    );

    ii_address_calc ii_addr7 (
        .x_pos_point(x_rect1_plus_w_rect1),
        .y_pos_point(y_rect1_plus_h_rect1),
        .width_ii(width_ii),
        .p_offset(p_offset),
        .ii_address(ii_address7)
    );

    /*
     * Rectangle 2
     */

    ii_address_calc ii_addr8 (
        .x_pos_point(x_rect2),
        .y_pos_point(y_rect2),
        .width_ii(width_ii),
        .p_offset(p_offset),
        .ii_address(ii_address8)
    );

    ii_address_calc ii_addr9 (
        .x_pos_point(x_rect2_plus_w_rect2),
        .y_pos_point(y_rect2),
        .width_ii(width_ii),
        .p_offset(p_offset),
        .ii_address(ii_address9)
    );

    ii_address_calc ii_addr10 (
        .x_pos_point(x_rect2),
        .y_pos_point(y_rect2_plus_h_rect2),
        .width_ii(width_ii),
        .p_offset(p_offset),
        .ii_address(ii_address10)
    );

    ii_address_calc ii_addr11 (
        .x_pos_point(x_rect2_plus_w_rect2),
        .y_pos_point(y_rect2_plus_h_rect2),
        .width_ii(width_ii),
        .p_offset(p_offset),
        .ii_address(ii_address11)
    );

    /*
     * MUX control
     */
    always @(*) begin
        case (ii_reg_index)

            4'h0: ii_address = ii_address0;
            4'h1: ii_address = ii_address1;
            4'h2: ii_address = ii_address2;
            4'h3: ii_address = ii_address3;

            4'h4: ii_address = ii_address4;
            4'h5: ii_address = ii_address5;
            4'h6: ii_address = ii_address6;
            4'h7: ii_address = ii_address7;

            4'h8: ii_address = ii_address8;
            4'h9: ii_address = ii_address9;
            4'hA: ii_address = ii_address10;
            4'hB: ii_address = ii_address11;

            default: ii_address = ii_address0;

        endcase
    end

endmodule
